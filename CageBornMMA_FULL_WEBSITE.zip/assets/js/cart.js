
function addToCart(item){
    let cart = JSON.parse(localStorage.getItem('cart')||'[]');
    cart.push(item);
    localStorage.setItem('cart', JSON.stringify(cart));
    alert('Added to cart');
}
function loadCart(){
    let cart = JSON.parse(localStorage.getItem('cart')||'[]');
    let html = '';
    let total = 0;
    cart.forEach(i=>{
        html += `<p>${i.name} x${i.quantity} — R${i.price * i.quantity}</p>`;
        total += i.price * i.quantity;
    });
    document.getElementById('cart-items').innerHTML = html || 'Cart empty';
    document.getElementById('total').innerText = total;
}
